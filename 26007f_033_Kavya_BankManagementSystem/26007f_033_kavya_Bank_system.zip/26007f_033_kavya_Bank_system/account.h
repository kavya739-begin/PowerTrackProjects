#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

class Account
{
private:
    int accountNumber;
    std::string holderName;
    char accountType; // 'S' for Savings, 'C' for Current
    double balance;
    std::string password;

public:
    void createAccount();
    void showAccount() const;
    void modifyAccount();
    void deposit(double amount);
    void withdraw(double amount);

    int getAccountNumber() const;
    double getBalance() const;
    char getAccountType() const;
    std::string getHolderName() const;
    std::string getPassword() const;

    // encrypt data back
    void setAccountData(int accNum, std::string name, char type, double bal, std::string pass);
};

#endif

