#include <iostream>
#include "bank_management.h"

int main()
{
    BankManagement bank;
    int choice;
    int accountNumber;

    do
    {
        std::cout << "\n\n===============================";
        std::cout << "\n   BANK MANAGEMENT SYSTEM";
        std::cout << "\n===============================";
        std::cout << "\n1. OPEN NEW ACCOUNT";
        std::cout << "\n2. DEPOSIT FUNDS";
        std::cout << "\n3. WITHDRAW FUNDS";
        std::cout << "\n4. BALANCE ENQUIRY";
        std::cout << "\n5. LIST ALL ACCOUNTS";
        std::cout << "\n6. CLOSE AN ACCOUNT";
        std::cout << "\n7. EXIT";
        std::cout << "\nChoose Option (1-7): ";

        std::cin >> choice;

        if(std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(1000, '\n');
            std::cout << "\nInvalid input choice. Please select numbers 1 to 7.";
            continue;
        }

        switch(choice)
        {
            case 1:
                bank.writeAccount();
                break;
            case 2:
                std::cout << "\nEnter Account Number: ";
                std::cin >> accountNumber;
                bank.depositWithdraw(accountNumber, 1);
                break;
            case 3:
                std::cout << "\nEnter Account Number: ";
                std::cin >> accountNumber;
                bank.depositWithdraw(accountNumber, 2);
                break;
            case 4:
                std::cout << "\nEnter Account Number: ";
                std::cin >> accountNumber;
                bank.displayAccount(accountNumber);
                break;
            case 5:
                bank.displayAll();
                break;
            case 6:
                std::cout << "\nEnter Account Number to Close: ";
                std::cin >> accountNumber;
                bank.deleteAccount(accountNumber);
                break;
            case 7:
                std::cout << "\nThank you for choosing our banking services.";
                break;
            default:
                std::cout << "\nOption out of bounds!";
        }
    } while (choice != 7);

    return 0;
}
