#include <iostream>
#include <iomanip>
#include "account.h"

void Account::createAccount()
{
    std::cout << "\nEnter Account Number: ";
    std::cin >> accountNumber;
    std::cin.ignore(); // Clear newline character from buffer

    std::cout << "Enter Account Holder Name: ";
    std::getline(std::cin, holderName);

    std::cout << "Enter Account Type (S for Savings / C for Current): ";
    std::cin >> accountType;
    accountType = toupper(accountType);

    std::cout << "Enter Initial Deposit Amount: ";
    std::cin >> balance;

    std::cout << "Create a Secure Password: ";
    std::cin >> password;

    std::cout << "\nAccount Created Successfully!";
}

void Account::showAccount() const {
    std::cout << "\nAccount Number  : " << accountNumber;
    std::cout << "\nHolder Name     : " << holderName;
    std::cout << "\nAccount Type    : " << (accountType == 'S' ? "Savings" : "Current");
    std::cout << "\nCurrent Balance : Rs." << std::fixed << std::setprecision(2) << balance;
}

void Account::modifyAccount() {
    std::cout << "\nAccount Number: " << accountNumber;
    std::cin.ignore();
    std::cout << "\nModify Account Holder Name: ";
    std::getline(std::cin, holderName);
    std::cout << "Modify Account Type (S/C): ";
    std::cin >> accountType;
    accountType = toupper(accountType);
}

void Account::deposit(double amount) {
    if (amount > 0)
    {
        balance += amount;
        std::cout << "\nRs." << amount << " deposited successfully.";
    }
    else
    {
        std::cout << "\nInvalid deposit amount!";
    }
}

void Account::withdraw(double amount) {
    if (amount <= 0)
    {
        std::cout << "\nInvalid withdrawal amount!";
    }
    else if (amount > balance)
    {
        std::cout << "\nTransaction Denied! Insufficient balance.";
    }
    else
    {
        balance -= amount;
        std::cout << "\nRs." << amount << " withdrawn successfully.";
    }
}

int Account::getAccountNumber() const
{
    return accountNumber;
}
double Account::getBalance() const
{
    return balance;
}
char Account::getAccountType() const
{
    return accountType;
}
std::string Account::getHolderName() const
{
    return holderName;
}
std::string Account::getPassword() const
{
    return password;
}

void Account::setAccountData(int accNum, std::string name, char type, double bal, std::string pass) {
    accountNumber = accNum;
    holderName = name;
    accountType = type;
    balance = bal;
    password = pass;
}
