#include <iostream>
#include <fstream>
#include <sstream>
#include "bank_management.h"

std::string BankManagement::encrypt(std::string text)  // encrypt
{
    for (size_t i = 0; i < text.length(); i++)
    {
        if (text[i] != ' ') text[i] = text[i] + 1;
    }
    return text;
}

std::string BankManagement::decrypt(std::string text) // decrypt
{
    for (size_t i = 0; i < text.length(); i++)
    {
        if (text[i] != ' ') text[i] = text[i] - 1;
    }
    return text;
}

void BankManagement::logTransaction(int accNum, std::string action, double amount)  // transaction history
{
    std::ofstream logFile("transactions.log", std::ios::app);
    if (logFile)
    {
        logFile << "Account [" << accNum << "] performed " << action << " of $" << amount << "\n";
        logFile.close();
    }
}

void BankManagement::writeAccount()
{
    Account acc;
    acc.createAccount();

    std::ofstream outFile("accounts.txt", std::ios::app);
    if (!outFile)
    {
        std::cout << "\nFile Error! Could not open database.";
        return;
    }

    std::string encryptedName = encrypt(acc.getHolderName());
    std::string encryptedPassword = encrypt(acc.getPassword());

    outFile << acc.getAccountNumber() << "," << encryptedName << "," << acc.getAccountType() << "," << acc.getBalance() << "," << encryptedPassword << "\n";

    outFile.close();
    logTransaction(acc.getAccountNumber(), "ACCOUNT CREATION", acc.getBalance());
}

void BankManagement::displayAccount(int accNum)
{
    std::ifstream inFile("accounts.txt");
    if (!inFile)
    {
        std::cout << "\nDatabase empty or unavailable.";
        return;
    }

    std::string line;
    bool found = false;

    while (std::getline(inFile, line))
    {
        std::stringstream ss(line);
        std::string s_id, s_name, s_type, s_bal, s_pass;

        std::getline(ss, s_id, ',');
        std::getline(ss, s_name, ',');
        std::getline(ss, s_type, ',');
        std::getline(ss, s_bal, ',');
        std::getline(ss, s_pass, ',');

        if (std::stoi(s_id) == accNum)
        {
            std::cout << "\n--- Verifying Password ---";
            std::string inputPass;
            std::cout << "\nEnter password for this account: ";
            std::cin >> inputPass;

            if (inputPass == decrypt(s_pass))
            {
                Account acc;
                acc.setAccountData(std::stoi(s_id), decrypt(s_name), s_type[0], std::stod(s_bal), decrypt(s_pass));
                std::cout << "\n=== ACCOUNT DETAILS ===";
                acc.showAccount();
            }
            else
            {
                std::cout << "\nIncorrect Password Access Denied.";
            }
            found = true;
            break;
        }
    }
    if (!found) std::cout << "\nAccount record not found.";
    inFile.close();
}

void BankManagement::depositWithdraw(int accNum, int actionType)
{
    std::ifstream inFile("accounts.txt");
    std::ofstream tempFile("temp.txt");

    if (!inFile || !tempFile)
    {
        std::cout << "\nDatabase file parsing error.";
        return;
    }

    std::string line;
    bool found = false;

    while (std::getline(inFile, line))
    {
        std::stringstream ss(line);
        std::string s_id, s_name, s_type, s_bal, s_pass;

        std::getline(ss, s_id, ',');
        std::getline(ss, s_name, ',');
        std::getline(ss, s_type, ',');
        std::getline(ss, s_bal, ',');
        std::getline(ss, s_pass, ',');

        if (std::stoi(s_id) == accNum)
        {
            Account acc;
            acc.setAccountData(std::stoi(s_id), decrypt(s_name), s_type[0], std::stod(s_bal), decrypt(s_pass));

            double amt;
            if (actionType == 1)
            {
                std::cout << "\nEnter amount to Deposit: ";
                std::cin >> amt;
                acc.deposit(amt);
                logTransaction(accNum, "DEPOSIT", amt);
            }
            else if (actionType == 2)
            {
                std::cout << "\nEnter amount to Withdraw: ";
                std::cin >> amt;
                acc.withdraw(amt);
                logTransaction(accNum, "WITHDRAWAL", amt);
            }

            tempFile << acc.getAccountNumber() << "," << encrypt(acc.getHolderName()) << "," << acc.getAccountType() << "," << acc.getBalance() << "," << encrypt(acc.getPassword()) << "\n";
            found = true;
        }
        else
        {
            tempFile << line << "\n";
        }
    }

    inFile.close();
    tempFile.close();

    std::remove("accounts.txt");
    std::rename("temp.txt", "accounts.txt");

    if (!found) std::cout << "\nAccount ID matching error.";
}

void BankManagement::displayAll()
{
    std::ifstream inFile("accounts.txt");
    if (!inFile)
    {
        std::cout << "\nDatabase empty.";
        return;
    }

    std::string line;
    std::cout << "\n==================================================";
    std::cout << "\nACC NO.\t\tNAME\t\tTYPE\tBALANCE";
    std::cout << "\n==================================================";

    while (std::getline(inFile, line))
    {
        std::stringstream ss(line);
        std::string s_id, s_name, s_type, s_bal, s_pass;

        std::getline(ss, s_id, ',');
        std::getline(ss, s_name, ',');
        std::getline(ss, s_type, ',');
        std::getline(ss, s_bal, ',');
        std::getline(ss, s_pass, ',');

        std::cout << "\n" << s_id << "\t\t" << decrypt(s_name) << "\t\t" << s_type << "\t$" << s_bal;
    }
    inFile.close();
}

void BankManagement::deleteAccount(int accNum)
{
    std::ifstream inFile("accounts.txt");
    std::ofstream tempFile("temp.txt");
    std::string line;
    bool found = false;

    while (std::getline(inFile, line))
    {
        std::stringstream ss(line);
        std::string s_id;
        std::getline(ss, s_id, ',');

        if (std::stoi(s_id) != accNum)
        {
            tempFile << line << "\n";
        }
        else
        {
            found = true;
        }
    }
    inFile.close();
    tempFile.close();
    std::remove("accounts.txt");
    std::rename("temp.txt", "accounts.txt");

    if (found)
    {
        std::cout << "\nAccount Deleted Successfully.";
        logTransaction(accNum, "ACCOUNT CLOSED", 0);
    }
    else
    {
        std::cout << "\nAccount Not Found.";
    }
}

