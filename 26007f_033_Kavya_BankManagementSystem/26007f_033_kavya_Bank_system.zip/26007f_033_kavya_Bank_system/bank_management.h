#ifndef BANK_MANAGEMENT_H
#define BANK_MANAGEMENT_H

#include "account.h"
#include <string>

class BankManagement
{
private:
    std::string encrypt(std::string text);
    std::string decrypt(std::string text);

    void logTransaction(int accNum, std::string action, double amount);

public:
    void writeAccount();             // Save new account to file
    void displayAccount(int accNum);  // Search and display an account
    void displayAll();               // List all accounts
    void depositWithdraw(int accNum, int actionType); // Deposit=1, Withdraw=2
    void deleteAccount(int accNum);  // Delete an account record
    void modifyAccountRecord(int accNum); // Modify name/type
};

#endif

