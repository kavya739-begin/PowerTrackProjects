#include "file_handler.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

static const string FILENAME = "documents.txt";

void FileHandler::loadDocuments(vector<Document> &documents)
{
    ifstream file(FILENAME);

    if (!file)
    {
        cout << "No existing database found. Starting fresh.\n";
        return;
    }

    string line;

    while (getline(file, line))
    {
        stringstream ss(line);
        Document doc;
        string idString;

        if (!getline(ss, idString, '|'))
            continue;

        if (!getline(ss, doc.title, '|'))
            continue;

        if (!getline(ss, doc.category, '|'))
            continue;

        if (!getline(ss, doc.date, '|'))
            continue;

        if (!getline(ss, doc.content))
            continue;

        try
        {
            doc.id = stoi(idString);
        }
        catch (...)
        {
            continue;
        }

        documents.push_back(doc);
    }

    file.close();
    cout << documents.size() << " documents loaded successfully.\n";
}

void FileHandler::saveDocuments(const vector<Document> &documents)
{
    ofstream file(FILENAME);

    if (!file)
    {
        cout << "Error saving database.\n";
        return;
    }

    for (const Document &doc : documents)
    {
        file << doc.id << '|' << doc.title << '|' << doc.category << '|' << doc.date << '|' << doc.content << '\n';
    }

    file.close();
}

