#include <iostream>
#include "document.h"

using namespace std;

void displayDocument(const Document &doc)
{
    cout << "\n----------------------------------\n";
    cout << "Document ID : " << doc.id << '\n';
    cout << "Title       : " << doc.title << '\n';
    cout << "Category    : " << doc.category << '\n';
    cout << "Date        : " << doc.date << '\n';
    cout << "Content     : " << doc.content << '\n';
    cout << "----------------------------------\n";
}
