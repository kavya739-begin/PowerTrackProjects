#include "search_engine.h"
#include "file_handler.h"

#include <iostream>
#include <algorithm>
#include <unordered_map>
#include <set>

using namespace std;

SearchEngine::SearchEngine()
{
    FileHandler::loadDocuments(documents);

    for (const Document &doc : documents)
    {
        indexer.indexDocument(doc.id, doc.title, doc.category, doc.content);
    }
}

const Document* SearchEngine::findDocument(int id) const
{
    for (const Document &doc : documents)
    {
        if (doc.id == id)
        {
            return &doc;
        }
    }

    return nullptr;
}

void SearchEngine::addDocument()
{
    Document doc;
    int maxId = 0;

    for (const Document &existing : documents)
    {
        maxId = max(maxId, existing.id);
    }
    doc.id = maxId + 1;

    cout << "\nEnter document title: ";
    getline(cin, doc.title);

    cout << "Enter category: ";
    getline(cin, doc.category);

    cout << "Enter date (YYYY-MM-DD): ";
    getline(cin, doc.date);

    cout << "Enter document content: ";
    getline(cin, doc.content);

    if (doc.title.empty() || doc.category.empty() || doc.date.empty() || doc.content.empty())
    {
        cout << "All fields are required.\n";
        return;
    }

    if (doc.title.find('|') != string::npos || doc.category.find('|') != string::npos || doc.date.find('|') != string::npos || doc.content.find('|') != string::npos)
    {
        cout << "The '|' character is not allowed.\n";
        return;
    }

    documents.push_back(doc);
    indexer.indexDocument(doc.id, doc.title, doc.category, doc.content);
    FileHandler::saveDocuments(documents);
    cout << "\nDocument added successfully. ID: " << doc.id << '\n';
}

void SearchEngine::searchDocuments()
{
    string query;

    cout << "\nEnter search keywords: ";
    getline(cin, query);

    vector<string> words = indexer.tokenize(query);

    if (words.empty())
    {
        cout << "Please enter valid search keywords.\n";
        return;
    }
    set<string> uniqueWords(words.begin(), words.end());
    unordered_map<int, int> scores;
    for (const string &word : uniqueWords)
    {
        unordered_map<int, int> matches = indexer.searchPartialWord(word);
        for (const auto &entry : matches)
        {
            scores[entry.first] += entry.second;
        }
    }

    vector<pair<int, int>> results;
    for (const auto &entry : scores)
    {
        results.push_back({entry.first, entry.second});
    }
    sort(results.begin(), results.end(), [this](const pair<int, int> &a, const pair<int, int> &b)
         {
             if (a.second != b.second)
                 return a.second > b.second;

             const Document *docA = findDocument(a.first);
             const Document *docB = findDocument(b.first);

             return docA->date > docB->date;
         });

    if (results.empty())
    {
        cout << "\nNo matching documents found.\n";
        return;
    }
    cout << "\nSearch Results: " << results.size() << '\n';
    for (const auto &result : results)
    {
        const Document *doc = findDocument(result.first);
        if (doc != nullptr)
        {
            cout << "\nRelevance Score: " << result.second;
            displayDocument(*doc);
        }
    }
}

void SearchEngine::browseDocuments()
{
    if (documents.empty())
    {
        cout << "\nNo documents available.\n";
        return;
    }
    cout << "\n========== ALL INDEXED DOCUMENTS ==========\n";
    for (const Document &doc : documents)
    {
        displayDocument(doc);
    }
}

