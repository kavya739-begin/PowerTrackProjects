/* Name: Kavya.M
   Description: Developed a C++-based Mini Search Engine that enables efficient searching of locally stored documents using keywords and partial keyword matching.
    Implemented an inverted index using STL containers such as unordered_map, vector, and set to improve search efficiency and rank relevant results.
    - Document module � create and display a document.
    - File Handler module � save and load documents.
    - Indexer module � tokenize text and build the inverted index.
    - Search Engine module � search using keywords and rank results.
    - Main module � connect everything through the menu.
*/
#include <iostream>
#include <sstream>
#include <string>
#include "search_engine.h"

using namespace std;

int main()
{
    SearchEngine engine;
    int choice;
    do
    {
        cout << "\n========== MINI SEARCH ENGINE ==========\n";
        cout << "1. Add Document\n";
        cout << "2. Search Documents\n";
        cout << "3. Browse All Documents\n";
        cout << "4. Exit\n";
        cout << "=========================================\n";

        cout << "Enter your choice: ";

        string input;
        getline(cin, input);

        stringstream ss(input);

        if (!(ss >> choice) || (ss >> ws && !ss.eof()))
        {
            cout << "Invalid input. Enter a number.\n";
            continue;
        }

        switch (choice)
        {
            case 1:
                engine.addDocument();
                break;

            case 2:
                engine.searchDocuments();
                break;

            case 3:
                engine.browseDocuments();
                break;

            case 4:
                cout << "\nExiting Search Engine...\n";
                break;

            default:
                cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 4);

    return 0;
}
