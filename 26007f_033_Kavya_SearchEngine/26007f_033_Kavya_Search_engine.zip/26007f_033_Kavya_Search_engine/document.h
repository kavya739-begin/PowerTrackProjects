#ifndef DOCUMENT_H
#define DOCUMENT_H

#include <string>

struct Document
{
    int id;
    std::string title;
    std::string category;
    std::string date;
    std::string content;
};

void displayDocument(const Document &doc);

#endif

