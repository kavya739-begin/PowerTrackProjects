#ifndef INDEXER_H
#define INDEXER_H

#include <string>
#include <vector>
#include <unordered_map>

class Indexer
{
private:
    std::unordered_map<std::string, std::unordered_map<int, int>> invertedIndex;

public:
    std::vector<std::string> tokenize(const std::string &text);
    void indexDocument(int id, const std::string &title, const std::string &category, const std::string &content);
    std::unordered_map<int, int> searchPartialWord(const std::string &word) const;
};

#endif

