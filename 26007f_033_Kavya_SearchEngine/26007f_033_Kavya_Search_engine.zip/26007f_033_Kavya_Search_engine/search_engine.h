#ifndef SEARCH_ENGINE_H
#define SEARCH_ENGINE_H

#include <vector>
#include <string>
#include "document.h"
#include "indexer.h"

class SearchEngine
{
private:
    std::vector<Document> documents;
    Indexer indexer;
    const Document* findDocument(int id) const;

public:
    SearchEngine();
    void addDocument();
    void searchDocuments();
    void browseDocuments();
};

#endif

