#include "indexer.h"
#include <cctype>

using namespace std;

vector<string> Indexer::tokenize(const string &text)
{
    vector<string> words;
    string word;

    for (unsigned char ch : text)
    {
        if (isalnum(ch))
        {
            word += static_cast<char>(tolower(ch));
        }
        else if (!word.empty())
        {
            words.push_back(word);
            word.clear();
        }
    }

    if (!word.empty())
    {
        words.push_back(word);
    }

    return words;
}

void Indexer::indexDocument(int id, const string &title, const string &category, const string &content)
{
    vector<string> words = tokenize(title + " " + category + " " + content);
    for (const string &word : words)
    {
        invertedIndex[word][id]++;
    }
}

unordered_map<int, int> Indexer::searchPartialWord(const string &word) const
{
    unordered_map<int, int> results;
    for(const auto &entry : invertedIndex)
    {
        if (entry.first.find(word) != string::npos)
        {
            for (const auto &doc : entry.second)
            {
                results[doc.first] += doc.second;
            }
        }
    }
    return results;
}


