#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include <vector>
#include "document.h"

class FileHandler
{
public:
    static void loadDocuments(std::vector<Document> &documents);

    static void saveDocuments(const std::vector<Document> &documents);
};

#endif

