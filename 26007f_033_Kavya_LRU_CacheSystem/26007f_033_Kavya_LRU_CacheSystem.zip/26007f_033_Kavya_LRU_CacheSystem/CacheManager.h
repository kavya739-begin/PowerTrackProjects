#ifndef CACHE_MANAGER_H
#define CACHE_MANAGER_H

#include "LRUCache.h"

class CacheManager
{
private:
    LRUCache cache;
    int hits;
    int misses;
    int evictions;

public:
    CacheManager(int capacity);
    void insert(int key, string value);
    void search(int key);
    void displayCache() const;
    void displayStatistics() const;
    void clearCache();
    void restoreCache(const vector<pair<int, string>> &entries);
    vector<pair<int, string>> getCacheEntries() const;
    int getCapacity() const;
};

#endif

