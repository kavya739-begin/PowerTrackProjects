#include "LRUCache.h"

LRUCache::LRUCache(int cap)
{
    capacity = (cap > 0) ? cap : 1;
}

bool LRUCache::get(int key, string &value)
{
    auto it = cacheMap.find(key);

    if (it == cacheMap.end())
    {
        return false;
    }
    value = it->second->second;
    cache.splice(cache.begin(), cache, it->second);

    return true;
}

bool LRUCache::put(int key, string value)
{
    auto it = cacheMap.find(key);
    if (it != cacheMap.end())
    {
        it->second->second = value;
        cache.splice(cache.begin(), cache, it->second);
        return false;
    }

    bool evicted = false;
    if ((int)cache.size() == capacity)
    {
        int lruKey = cache.back().first;
        cacheMap.erase(lruKey);
        cache.pop_back();
        evicted = true;
    }
    cache.push_front({key, value});
    cacheMap[key] = cache.begin();
    return evicted;
}

void LRUCache::display() const
{
    if (cache.empty())
    {
        cout << "\nCache is empty!\n";
        return;
    }

    cout << "\nCache Contents (MRU -> LRU)\n";

    for (const auto &item : cache)
    {
        cout << "Key: " << item.first << " | Value: " << item.second << endl;
    }
}

void LRUCache::clear()
{
    cache.clear();
    cacheMap.clear();
}

int LRUCache::getCapacity() const
{
    return capacity;
}

int LRUCache::getSize() const
{
    return (int)cache.size();
}

vector<pair<int, string>> LRUCache::getEntries() const
{
    return vector<pair<int, string>>(cache.begin(), cache.end());
}

void LRUCache::loadEntries(const vector<pair<int, string>> &entries)
{
    clear();
    for (auto it = entries.rbegin(); it != entries.rend(); ++it)
    {
        if (getSize() == capacity)
        {
            break;
        }
        put(it->first, it->second);
    }
}

