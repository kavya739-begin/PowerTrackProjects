#include <iostream>
#include <limits>
#include "CacheManager.h"
#include "file_handler.h"

using namespace std;

int main()
{
    int capacity;

    cout << "====================================\n";
    cout << "       LRU CACHE MANAGEMENT SYSTEM\n";
    cout << "====================================\n";

    cout << "\nEnter cache capacity: ";

    if (!(cin >> capacity) || capacity <= 0)
    {
        cout << "Invalid capacity!\n";
        return 1;
    }

    CacheManager manager(capacity);

    int choice;
    int key;
    string value;

    vector<pair<int, string>> entries;

    do
    {
        cout << "\n========== MAIN MENU ==========\n";
        cout << "1. Insert / Update Cache\n";
        cout << "2. Search Cache\n";
        cout << "3. Display Cache\n";
        cout << "4. Display Statistics\n";
        cout << "5. Save Cache to File\n";
        cout << "6. Load Cache from File\n";
        cout << "7. Clear Cache\n";
        cout << "8. Exit\n";
        cout << "===============================\n";

        cout << "\nEnter your choice: ";

        if (!(cin >> choice))
        {
            cout << "Invalid input!\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice)
        {
            case 1:
                cout << "Enter key: ";
                cin >> key;

                cout << "Enter value: ";
                cin >> ws;
                getline(cin, value);

                manager.insert(key, value);
                break;

            case 2:
                cout << "Enter key to search: ";
                cin >> key;

                manager.search(key);
                break;

            case 3:
                manager.displayCache();
                break;

            case 4:
                manager.displayStatistics();
                break;

            case 5:
                entries = manager.getCacheEntries();

                saveCache("cache_data.txt", entries);
                break;

            case 6:
                if (loadCache("cache_data.txt", entries))
                {
                    manager.restoreCache(entries);
                    cout << "Cache restored successfully!\n";
                }
                break;

            case 7:
                manager.clearCache();
                break;

            case 8:
                cout << "\nExiting LRU Cache System...\n";
                break;

            default:
                cout << "\nInvalid choice! Try again.\n";
        }

    } while (choice != 8);

    return 0;
}
