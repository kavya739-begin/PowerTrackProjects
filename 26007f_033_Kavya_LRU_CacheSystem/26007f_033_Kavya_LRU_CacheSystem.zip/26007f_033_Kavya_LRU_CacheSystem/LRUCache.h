#ifndef LRU_CACHE_H
#define LRU_CACHE_H

#include <iostream>
#include <list>
#include <unordered_map>
#include <string>
#include <vector>

using namespace std;

class LRUCache
{
private:
    int capacity;
    list<pair<int, string>> cache;
    unordered_map<int, list<pair<int, string>>::iterator> cacheMap;

public:
    LRUCache(int cap);
    bool get(int key, string &value);
    bool put(int key, string value);
    void display() const;
    void clear();
    int getCapacity() const;
    int getSize() const;
    vector<pair<int, string>> getEntries() const;
    void loadEntries(const vector<pair<int, string>> &entries);
};

#endif

