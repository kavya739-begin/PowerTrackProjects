#include "CacheManager.h"

CacheManager::CacheManager(int capacity) : cache(capacity)
{
    hits = 0;
    misses = 0;
    evictions = 0;
}

void CacheManager::insert(int key, string value)
{
    bool evicted = cache.put(key, value);
    if (evicted)
    {
        evictions++;
        cout << "\nLRU element evicted successfully!\n";
    }
    cout << "Cache insertion/update successful!\n";
}

void CacheManager::search(int key)
{
    string value;
    if (cache.get(key, value))
    {
        hits++;
        cout << "\nCache HIT!";
        cout << "\nKey: " << key;
        cout << "\nValue: " << value << endl;
    }
    else
    {
        misses++;
        cout << "\nCache MISS!";
        cout << "\nKey not found.\n";
    }
}

void CacheManager::displayCache() const
{
    cache.display();
}

void CacheManager::displayStatistics() const
{
    cout << "\n========== CACHE STATISTICS ==========\n";
    cout << "Capacity       : " << cache.getCapacity() << endl;
    cout << "Current Size   : " << cache.getSize() << endl;
    cout << "Cache Hits     : " << hits << endl;
    cout << "Cache Misses   : " << misses << endl;
    cout << "Evictions      : " << evictions << endl;

    int total = hits + misses;

    if (total > 0)
    {
        double hitRatio = (double)hits / total * 100;

        cout << "Hit Ratio      : " << hitRatio << "%\n";
    }
    else
    {
        cout << "Hit Ratio      : 0%\n";
    }

    cout << "======================================\n";
}

void CacheManager::clearCache()
{
    cache.clear();
    hits = 0;
    misses = 0;
    evictions = 0;

    cout << "\nCache cleared successfully!\n";
}

void CacheManager::restoreCache(const vector<pair<int, string>> &entries)
{
    cache.loadEntries(entries);

    hits = 0;
    misses = 0;
    evictions = 0;
}

vector<pair<int, string>> CacheManager::getCacheEntries() const
{
    return cache.getEntries();
}

int CacheManager::getCapacity() const
{
    return cache.getCapacity();
}

