/*
  Name : Kavya M
  Title : LRU Cache System
  Description : Least Recently Used (LRU) Cache Management System developed using C++.It is a program that temporarily stores
  data so that frequently or recently accessed data can be retrieved quickly. When the cache becomes full, it automatically removes
  the data that has not been accessed for the longest time(LRU) by LRU eviction.
  Insert / Update Cache � Adds a new key-value pair or updates an existing key's value.
  Search Cache � Searches for a key and retrieves its corresponding value.
  Display Cache � Displays all stored elements in Most Recently Used (MRU) to Least Recently Used (LRU) order.
  Display Statistics � Shows cache hits, misses, evictions and hit ratio.
  Save Cache to File � Stores the current cache contents in a file for future use.
  Load Cache from File � Restores previously saved cache contents from a file.
  Clear Cache � Removes all stored elements and resets cache statistics.
  Exit � Terminates the LRU Cache Management System.
*/

#include "file_handler.h"

bool saveCache(const string &filename, const vector<pair<int, string>> &entries)
{
    ofstream file(filename);
    if (!file.is_open())
    {
        cout << "\nUnable to open file for saving!\n";
        return false;
    }
    for (const auto &entry : entries)
    {
        file << entry.first << "|" << entry.second << "\n";
    }
    file.close();
    cout << "\nCache saved successfully!\n";
    return true;
}

bool loadCache(const string &filename, vector<pair<int, string>> &entries)
{
    ifstream file(filename);

    if (!file.is_open())
    {
        cout << "\nUnable to open cache file!\n";
        return false;
    }

    vector<pair<int, string>> temp;

    string line;

    while(getline(file, line))
    {
        size_t pos = line.find('|');
        if (pos == string::npos)
        {
            continue;
        }
        try
        {
            int key = stoi(line.substr(0, pos));
            string value = line.substr(pos + 1);
            temp.push_back({key, value});
        }
        catch (const exception &)
        {
            continue;
        }
    }
    file.close();
    entries = temp;
    cout << "\nCache loaded successfully!\n";
    return true;
}

