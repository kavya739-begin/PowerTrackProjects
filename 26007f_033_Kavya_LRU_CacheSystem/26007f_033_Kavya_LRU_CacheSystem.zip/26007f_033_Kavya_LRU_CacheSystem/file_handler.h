#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

bool saveCache(
    const string &filename,
    const vector<pair<int, string>> &entries
);

bool loadCache(
    const string &filename,
    vector<pair<int, string>> &entries
);

#endif

