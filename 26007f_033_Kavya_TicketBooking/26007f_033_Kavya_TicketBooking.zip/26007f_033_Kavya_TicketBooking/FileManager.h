#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "Ticket.h"
#include "Booking.h"
#include <vector>

class FileManager
{
public:
    static void loadTickets(vector<Ticket>& tickets);
    static void saveTickets(const vector<Ticket>& tickets);

    static void loadBookings(vector<Booking>& bookings);
    static void saveBookings(const vector<Booking>& bookings);
};

#endif
