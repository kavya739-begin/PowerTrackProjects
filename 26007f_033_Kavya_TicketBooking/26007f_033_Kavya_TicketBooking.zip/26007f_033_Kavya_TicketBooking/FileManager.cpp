#include "FileManager.h"
#include <fstream>
#include <sstream>

using namespace std;

void FileManager::loadTickets(vector<Ticket>& tickets)
{
    ifstream file("tickets.txt");

    if (!file)
        return;

    tickets.clear();

    int id, available;
    string name, category, date, location;
    double price;

    while (file >> id)
    {
        file.ignore();

        getline(file, name, '|');
        getline(file, category, '|');
        getline(file, date, '|');
        getline(file, location, '|');

        file >> price;
        file.ignore();
        file >> available;

        Ticket ticket(id, name, category, date, location, price, available);
        tickets.push_back(ticket);
    }

    file.close();
}

void FileManager::saveTickets(const vector<Ticket>& tickets)
{
    ofstream file("tickets.txt");

    for (const Ticket& ticket : tickets)
    {
        file << ticket.getTicketId() << " " << ticket.getTicketName() << "|" << ticket.getCategory() << "|" << ticket.getDate() << "|" << ticket.getLocation() << "|" << ticket.getPrice() << "|" << ticket.getAvailableTickets() << "\n";
    }

    file.close();
}

void FileManager::loadBookings(vector<Booking>& bookings)
{
    ifstream file("bookings.txt");

    if (!file)
        return;

    bookings.clear();

    int bookingId, ticketId, quantity;
    double amount;
    string name, email, phone;

    while (file >> bookingId >> ticketId >> quantity >> amount)
    {
        file.ignore();

        getline(file, name, '|');
        getline(file, email, '|');
        getline(file, phone);

        User user(name, email, phone);

        Booking booking(bookingId, ticketId, quantity, amount, user);
        bookings.push_back(booking);
    }

    file.close();
}

void FileManager::saveBookings(const vector<Booking>& bookings)
{
    ofstream file("bookings.txt");

    for (const Booking& booking : bookings)
    {
        User user = booking.getUser();

        file << booking.getBookingId() << " " << booking.getTicketId() << " " << booking.getQuantity() << " " << booking.getTotalAmount() << " " << user.getName() << "|" << user.getEmail() << "|" << user.getPhone() << "\n";
    }

    file.close();
}
