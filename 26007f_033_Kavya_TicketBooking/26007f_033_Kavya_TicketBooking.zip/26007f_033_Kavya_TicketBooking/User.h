#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User
{
private:
    string name;
    string email;
    string phone;

public:
    User();

    User(string name, string email, string phone);

    string getName() const;
    string getEmail() const;
    string getPhone() const;

    static bool validateName(const string& name);
    static bool validateEmail(const string& email);
    static bool validatePhone(const string& phone);

    void displayUser() const;
};

#endif
