#include "Ticket.h"
#include <iostream>

using namespace std;

Ticket::Ticket()
{
    ticketId = 0;
    price = 0;
    availableTickets = 0;
}

Ticket::Ticket(int id, string name, string cat, string dt, string loc, double cost, int available)
{
    ticketId = id;
    ticketName = name;
    category = cat;
    date = dt;
    location = loc;
    price = cost;
    availableTickets = available;
}

int Ticket::getTicketId() const
{
    return ticketId;
}

string Ticket::getTicketName() const
{
    return ticketName;
}

string Ticket::getCategory() const
{
    return category;
}

string Ticket::getDate() const
{
    return date;
}

string Ticket::getLocation() const
{
    return location;
}

double Ticket::getPrice() const
{
    return price;
}

int Ticket::getAvailableTickets() const
{
    return availableTickets;
}

bool Ticket::bookTickets(int quantity)
{
    if (quantity <= 0 || quantity > availableTickets)
        return false;

    availableTickets -= quantity;
    return true;
}

void Ticket::displayTicket() const
{
    cout << "\nTicket ID        : " << ticketId;
    cout << "\nName             : " << ticketName;
    cout << "\nCategory         : " << category;
    cout << "\nDate             : " << date;
    cout << "\nLocation         : " << location;
    cout << "\nPrice            : Rs. " << price;
    cout << "\nAvailable Tickets : " << availableTickets;
    cout << "\n----------------------------------\n";
}

void Ticket::cancelTickets(int quantity)
{
    if (quantity > 0)
        availableTickets += quantity;
}
