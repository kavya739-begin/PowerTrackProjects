#ifndef BOOKING_H
#define BOOKING_H

#include "User.h"

class Booking
{
private:
    int bookingId;
    int ticketId;
    int quantity;
    double totalAmount;
    User user;

public:
    Booking();

    Booking(int bookingId, int ticketId, int quantity, double amount, User user);

    int getBookingId() const;
    int getTicketId() const;
    int getQuantity() const;
    double getTotalAmount() const;
    User getUser() const;

    void displayBooking() const;
};

#endif
