#include "BookingSystem.h"
#include "FileManager.h"

#include <iostream>
#include <limits>

using namespace std;

BookingSystem::BookingSystem()
{
    FileManager::loadTickets(tickets);
    FileManager::loadBookings(bookings);
}

int BookingSystem::generateBookingId() const
{
    int maxId = 1000;

    for (const Booking& booking : bookings)
    {
        if (booking.getBookingId() > maxId)
            maxId = booking.getBookingId();
    }

    return maxId + 1;
}

void BookingSystem::displayTickets() const
{
    if (tickets.empty())
    {
        cout << "\nNo tickets available.\n";
        return;
    }

    cout << "\n========== AVAILABLE TICKETS ==========\n";

    for (const Ticket& ticket : tickets)
    {
        ticket.displayTicket();
    }
}

void BookingSystem::searchTickets() const
{
    string category;
    cout << "\nEnter category to search " << "(Movie/Train/Concert/Event): ";
    getline(cin, category);
    bool found = false;

    for (const Ticket& ticket : tickets)
    {
        if (ticket.getCategory() == category)
        {
            ticket.displayTicket();
            found = true;
        }
    }

    if (!found)
        cout << "\nNo tickets found in this category.\n";
}

void BookingSystem::bookTicket()
{
    int ticketId, quantity;

    cout << "\nEnter Ticket ID: ";
    cin >> ticketId;
    int index = -1;

    for(int i = 0; i < tickets.size(); i++)
    {
        if(tickets[i].getTicketId() == ticketId)
        {
            index = i;
            break;
        }
    }

    if (index == -1)
    {
        cout << "\nInvalid Ticket ID.\n";
        return;
    }

    Ticket& ticket = tickets[index];

    cout << "\nSelected Ticket: " << ticket.getTicketName();
    cout << "\nAvailable Tickets: " << ticket.getAvailableTickets();
    cout << "\nEnter quantity: ";
    cin >> quantity;

    if (quantity <= 0 || quantity > ticket.getAvailableTickets())
    {
        cout << "\nInvalid quantity or tickets unavailable.\n";
        return;
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    string name, email, phone;

    do
    {
        cout << "\nEnter passenger name: ";
        getline(cin, name);

        if (!User::validateName(name))
        {
            cout << "Invalid name! Use alphabets and spaces only.\n";
        }

    } while (!User::validateName(name));

    do
    {
        cout << "Enter passenger email: ";
        getline(cin, email);

        if (!User::validateEmail(email))
        {
            cout << "Invalid email! Email must be in a valid format " << "and end with .com\n";
        }

    } while (!User::validateEmail(email));

    do
    {
        cout << "Enter passenger phone number: ";
        getline(cin, phone);

        if (!User::validatePhone(phone))
        {
            cout << "Invalid phone! Enter a valid 10-digit " << "Indian mobile number.\n";
        }

    } while (!User::validatePhone(phone));

    double total = ticket.getPrice() * quantity;

    if(!ticket.bookTickets(quantity))
    {
        cout << "\nBooking failed.\n";
        return;
    }
    Booking booking(generateBookingId(), ticketId, quantity, total, User(name, email, phone));
    bookings.push_back(booking);
    saveData();

    cout << "\nBooking successful!";
    cout << "\nTotal amount: Rs. " << total;

    booking.displayBooking();
}

void BookingSystem::viewBookings() const
{
    if (bookings.empty())
    {
        cout << "\nNo bookings available.\n";
        return;
    }

    cout << "\n========== BOOKING HISTORY ==========\n";

    for (const Booking& booking : bookings)
    {
        booking.displayBooking();
    }
}

void BookingSystem::cancelBooking()
{
    int bookingId;

    cout << "\nEnter Booking ID to cancel: ";
    cin >> bookingId;

    for (int i = 0; i < bookings.size(); i++)
    {
        if (bookings[i].getBookingId() == bookingId)
        {
            int ticketId = bookings[i].getTicketId();
            int quantity = bookings[i].getQuantity();

            for (Ticket& ticket : tickets)
            {
                if (ticket.getTicketId() == ticketId)
                {
                    ticket.cancelTickets(quantity);
                    break;
                }
            }

            bookings.erase(bookings.begin() + i);

            saveData();

            cout << "\nBooking cancelled successfully!\n";
            cout << "Tickets returned to available inventory.\n";

            return;
        }
    }

    cout << "\nBooking ID not found.\n";
}

void BookingSystem::addTicket()
{
    int id, available;
    string name, category, date, location;
    double price;

    cout << "\nEnter Ticket ID: ";
    cin >> id;

    for (const Ticket& ticket : tickets)
    {
        if (ticket.getTicketId() == id)
        {
            cout << "\nTicket ID already exists.\n";
            return;
        }
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "Enter Ticket Name: ";
    getline(cin, name);

    cout << "Enter Category (Movie/Train/Concert/Event): ";
    getline(cin, category);

    cout << "Enter Date: ";
    getline(cin, date);

    cout << "Enter Location: ";
    getline(cin, location);

    cout << "Enter Price: ";
    cin >> price;

    cout << "Enter Available Tickets: ";
    cin >> available;

    if (price <= 0 || available <= 0)
    {
        cout << "\nInvalid price or ticket count.\n";
        return;
    }

    Ticket newTicket(id, name, category, date, location, price, available);
    tickets.push_back(newTicket);
    saveData();

    cout << "\nTicket added successfully!\n";
}

void BookingSystem::adminMenu()
{
    int choice;

    string password;

    cout << "\nEnter Admin Password: ";
    cin >> password;

    if (password != "admin123")
    {
        cout << "\nIncorrect password!\n";
        return;
    }

    do
    {
        cout << "\n========== ADMIN MENU ==========";
        cout << "\n1. View All Tickets";
        cout << "\n2. Add New Ticket";
        cout << "\n3. View All Bookings";
        cout << "\n4. Save Data";
        cout << "\n5. Back to Main Menu";
        cout << "\nEnter choice: ";

        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice)
        {
            case 1:
                displayTickets();
                break;

            case 2:
                addTicket();
                break;

            case 3:
                viewBookings();
                break;

            case 4:
                saveData();
                cout << "\nData saved successfully.\n";
                break;

            case 5:
                cout << "\nReturning to main menu...\n";
                break;

            default:
                cout << "\nInvalid choice.\n";
        }

    } while (choice != 5);
}

void BookingSystem::saveData()
{
    FileManager::saveTickets(tickets);
    FileManager::saveBookings(bookings);
}

