#ifndef BOOKINGSYSTEM_H
#define BOOKINGSYSTEM_H

#include "Ticket.h"
#include "Booking.h"
#include <vector>

class BookingSystem
{
private:
    vector<Ticket> tickets;
    vector<Booking> bookings;

    int generateBookingId() const;

public:
    BookingSystem();

    void displayTickets() const;
    void searchTickets() const;
    void bookTicket();
    void viewBookings() const;
    void cancelBooking();

    void addTicket();
    void adminMenu();

    void saveData();
};

#endif
