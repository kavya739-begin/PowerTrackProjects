#include "User.h"
#include <iostream>
#include <regex>

using namespace std;

User::User()
{
}

User::User(string n, string e, string p)
{
    name = n;
    email = e;
    phone = p;
}

string User::getName() const
{
    return name;
}

string User::getEmail() const
{
    return email;
}

string User::getPhone() const
{
    return phone;
}

bool User::validateName(const string& name)
{
    regex pattern("^[A-Za-z]+( [A-Za-z]+)*$");

    return regex_match(name, pattern);
}

bool User::validateEmail(const string& email)
{
    regex pattern("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$");
    return regex_match(email, pattern);
}

// Indian mobile validation: 10 digits, starting from 6 to 9
bool User::validatePhone(const string& phone)
{
    regex pattern("^[6-9][0-9]{9}$");
    return regex_match(phone, pattern);
}

void User::displayUser() const
{
    cout << "\nCustomer Name : " << name;
    cout << "\nEmail        : " << email;
    cout << "\nPhone        : " << phone;
}
