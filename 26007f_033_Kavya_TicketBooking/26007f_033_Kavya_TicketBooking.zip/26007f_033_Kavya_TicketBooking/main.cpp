#include <iostream>
#include <limits>
#include "BookingSystem.h"

using namespace std;

int main()
{
    BookingSystem system;
    int choice;

    do
    {
        cout << "\n====================================";
        cout << "\n       TICKET BOOKING PLATFORM";
        cout << "\n====================================";
        cout << "\n1. View Available Tickets";
        cout << "\n2. Search Tickets";
        cout << "\n3. Book Tickets";
        cout << "\n4. View Booking History";
        cout << "\n5. Cancel Booking";
        cout << "\n6. Admin Login";
        cout << "\n7. Exit";
        cout << "\n====================================";
        cout << "\nEnter your choice: ";

        if (!(cin >> choice))
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "\nInvalid input. Please enter a number.\n";
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice)
        {
            case 1:
                system.displayTickets();
                break;

            case 2:
                system.searchTickets();
                break;

            case 3:
                system.bookTicket();
                break;

            case 4:
                system.viewBookings();
                break;

            case 5:
                system.cancelBooking();
                break;

            case 6:
                system.adminMenu();
                break;

            case 7:
                system.saveData();
                cout << "\nThank you for using Ticket Booking Platform!\n";
                break;

            default:
                cout << "\nInvalid choice. Try again.\n";
        }

    } while (choice != 7);

    return 0;
}
