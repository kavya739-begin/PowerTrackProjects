#ifndef TICKET_H
#define TICKET_H

#include <string>
using namespace std;

class Ticket
{
private:
    int ticketId;
    string ticketName;
    string category;
    string date;
    string location;
    double price;
    int availableTickets;

public:
    Ticket();

    Ticket(int id, string name, string cat, string date, string location, double price, int available);
    int getTicketId() const;
    string getTicketName() const;
    string getCategory() const;
    string getDate() const;
    string getLocation() const;
    double getPrice() const;
    int getAvailableTickets() const;
    void cancelTickets(int quantity);

    bool bookTickets(int quantity);
    void displayTicket() const;
};

#endif
