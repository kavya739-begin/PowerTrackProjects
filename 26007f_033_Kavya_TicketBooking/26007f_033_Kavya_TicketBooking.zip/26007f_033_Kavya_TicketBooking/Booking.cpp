#include "Booking.h"
#include <iostream>

using namespace std;

Booking::Booking()
{
    bookingId = 0;
    ticketId = 0;
    quantity = 0;
    totalAmount = 0;
}

Booking::Booking(int id, int tid, int qty, double amount, User u)
{
    bookingId = id;
    ticketId = tid;
    quantity = qty;
    totalAmount = amount;
    user = u;
}

int Booking::getBookingId() const
{
    return bookingId;
}

int Booking::getTicketId() const
{
    return ticketId;
}

int Booking::getQuantity() const
{
    return quantity;
}

double Booking::getTotalAmount() const
{
    return totalAmount;
}

User Booking::getUser() const
{
    return user;
}

void Booking::displayBooking() const
{
    cout << "\n========== BOOKING DETAILS ==========";
    cout << "\nBooking ID     : " << bookingId;
    cout << "\nTicket ID      : " << ticketId;
    cout << "\nQuantity       : " << quantity;
    cout << "\nTotal Amount   : Rs. " << totalAmount;

    user.displayUser();

    cout << "\n==================================\n";
}
